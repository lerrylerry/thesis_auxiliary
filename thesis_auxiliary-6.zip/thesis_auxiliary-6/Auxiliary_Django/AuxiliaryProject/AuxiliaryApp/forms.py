from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from .models import login_user

class LoginForm(UserCreationForm):
    class meta:
        model = login_user
        fields = ['username','password']