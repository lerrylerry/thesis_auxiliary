from django.shortcuts import render, redirect
# from django.http import HttpResponse

from .models import *
from django.contrib.auth.forms import UserCreationForm
from .forms import LoginForm


from django.contrib.auth import authenticate, login, logout

'''<-----------------------------HOMEPAGE---------------------------------->'''

def index(request):
    return render(request, 'pages/homepage/home.html')

# def login(request):
#     return render(request, 'pages/homepage/login.html')

def login(request):
    # kukuha pa sa database
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        userType = request.POST['userType']

        user = authenticate(request, username=username, password=password, userType=userType)

        if user.userType == "ADMIN":
            return redirect("to something")
        elif user.userType == "REPAIR_MAN":
            return redirect("to something")
        elif user.userType == "UTILITY_PERSONNEL":
            return redirect("to something")
        elif user.userType == "ASSISTANT_DIRECTOR":
            return redirect("to something")
        else:
            return redirect("try again")

    return render(request, 'pages/homepage/login.html')

def logout(request):
    logout(request)
    return redirect('may pupuntahan')

'''<----------------------------------------------------------------------->'''

'''<-----------------------------ADMINPAGE--------------------------------->'''

def addItems(request):
    return render(request, 'pages/admin/addItems.html')

def addSupplies(request):
    return render(request, 'pages/admin/addSupplies.html')

def borrowed(request):
    return render(request, 'pages/admin/borrowed.html')

def history(request):
    return render(request, 'pages/admin/history.html')

def adminHomepage(request):
    return render(request, 'pages/admin/homepage.html')

def utilityPersonnel(request):
    return render(request, 'pages/admin/utilityPersonnel.html')

def utilityPersonnelList(request):
    return render(request, 'pages/admin/utilityPersonnelList.html')

def minorRepair(request):
    return render(request, 'pages/admin/minorRepair.html')

def vehicle(request):
    return render(request, 'pages/admin/vehicle.html')

def camera(request):
    return render(request, 'pages/admin/camera.html')

'''<----------------------------------------------------------------------->'''

'''<-----------------------------FORMSPAGE--------------------------------->'''

def adminForm(request):
    return render(request, 'pages/forms/admin-form.html')

def borrowForm(request):
    return render(request, 'pages/forms/borrow-form.html')

def clientForm(request):
    return render(request, 'pages/forms/client-form.html')

def personnelForm(request):
    return render(request, 'pages/forms/personnel-form.html')

def vehicleForm(request):
    return render(request, 'pages/forms/vehicle-form.html')

'''<----------------------------------------------------------------------->'''